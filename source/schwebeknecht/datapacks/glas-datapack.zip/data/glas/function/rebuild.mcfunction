execute unless score #next glas matches 0..8 run scoreboard players set #next glas 0
execute if score #next glas matches 1 run function glas:animate/reset/v1
execute if score #next glas matches 2 run function glas:animate/reset/v2
execute if score #next glas matches 3 run function glas:animate/reset/v3
execute if score #next glas matches 4 run function glas:animate/reset/v4
execute if score #next glas matches 5 run function glas:animate/reset/v5
execute if score #next glas matches 6 run function glas:animate/reset/v6
execute if score #next glas matches 7 run function glas:animate/reset/v7
execute if score #next glas matches 8 run function glas:animate/reset/v8
execute unless score #legacy glas matches 3 run function glas:legacy_clear_current
scoreboard players set #legacy glas 3
execute if score #next glas matches 1 run function glas:clear/1
execute if score #next glas matches 2 run function glas:clear/2
execute if score #next glas matches 3 run function glas:clear/3
execute if score #next glas matches 4 run function glas:clear/4
execute if score #next glas matches 5 run function glas:clear/5
execute if score #next glas matches 6 run function glas:clear/6
execute if score #next glas matches 7 run function glas:clear/7
execute if score #next glas matches 8 run function glas:clear/8
scoreboard players add #next glas 1
execute if score #next glas matches 9 run scoreboard players set #next glas 1
execute if score #next glas matches 1 run function glas:variant/1
execute if score #next glas matches 2 run function glas:variant/2
execute if score #next glas matches 3 run function glas:variant/3
execute if score #next glas matches 4 run function glas:variant/4
execute if score #next glas matches 5 run function glas:variant/5
execute if score #next glas matches 6 run function glas:variant/6
execute if score #next glas matches 7 run function glas:variant/7
execute if score #next glas matches 8 run function glas:variant/8
scoreboard players set #phase glas 1
scoreboard players set #clock glas 0
scoreboard players set #running glas 1
