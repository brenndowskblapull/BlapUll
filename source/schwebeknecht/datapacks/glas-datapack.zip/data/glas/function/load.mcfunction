scoreboard objectives add glas dummy
execute unless score #next glas matches 0..8 run scoreboard players set #next glas 0
execute unless score #legacy glas matches 0..3 run scoreboard players set #legacy glas 0
execute unless score #phase glas matches 0..3 run scoreboard players set #phase glas 1
execute unless score #clock glas matches 0..1 run scoreboard players set #clock glas 0
scoreboard players set #running glas 0
