execute unless score #next glas matches 1..8 run scoreboard players set #next glas 1
execute if score #next glas matches 1 run function glas:animate/prepare/v1
execute if score #next glas matches 2 run function glas:animate/prepare/v2
execute if score #next glas matches 3 run function glas:animate/prepare/v3
execute if score #next glas matches 4 run function glas:animate/prepare/v4
execute if score #next glas matches 5 run function glas:animate/prepare/v5
execute if score #next glas matches 6 run function glas:animate/prepare/v6
execute if score #next glas matches 7 run function glas:animate/prepare/v7
execute if score #next glas matches 8 run function glas:animate/prepare/v8
scoreboard players set #phase glas 1
scoreboard players set #clock glas 0
scoreboard players set #running glas 1
