execute if score #running glas matches 1 run scoreboard players add #clock glas 1
execute if score #running glas matches 1 if score #clock glas matches 2.. run function glas:animate/step
execute if score #running glas matches 1 if score #clock glas matches 2.. run scoreboard players set #clock glas 0
