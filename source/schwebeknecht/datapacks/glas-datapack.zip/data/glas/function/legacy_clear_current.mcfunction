execute if score #next glas matches 1 run function glas:legacy/clear/1
execute if score #next glas matches 2 run function glas:legacy/clear/2
execute if score #next glas matches 3 run function glas:legacy/clear/3
execute if score #next glas matches 4 run function glas:legacy/clear/4
execute if score #next glas matches 5 run function glas:legacy/clear/5
execute if score #next glas matches 6 run function glas:legacy/clear/6
execute if score #next glas matches 7 run function glas:legacy/clear/7
execute if score #next glas matches 8 run function glas:legacy/clear/8
